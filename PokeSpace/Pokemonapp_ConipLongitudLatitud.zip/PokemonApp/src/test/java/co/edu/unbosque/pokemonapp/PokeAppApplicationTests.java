package co.edu.unbosque.pokemonapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PokeAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
